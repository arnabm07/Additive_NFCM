###############################################################
# ex1_datagen.r - August/27/2015				#
# Script created by Janet Kim				#
# Contents:						#
# (i)   Tr.data.dn: densely sampled training data			#
#       Tr.data.sp: sparsely sampled training data			#
# (ii)  Tt.data1, Tt.data2: test data				#
# (iii) null.data.dn: densely sampled data used in hypothesis testing	#
#       null.data.sp: sparsely sampled data used in hypothesis testing	#
###############################################################
library(MASS); source("datagenALL.r")

Tr.data.dn = datagen(# Y(t) = F.nlin(x,t) + error(t)
		     n=50,			# 50 subjects 
		     m=81,			# 81 observations/subject
		     F=list(F.nlin),
		     Q = 1,         		# single functional covariate
		     error_type=3,		# KL + WN error structure
		     tau=0.35,		# variance of WN error in covariate 
		     sig2noise=0.8,		# variance of WN error in response
		     seed=10		# seed number
		    )

Tr.data.sp = datagen(# Y(t) = F.nlin(x,t) + F.nlin2(x,t) + error(t)
		     n=50,			# 50 subjects 
		     m=81,			# 81 observations/subject
		     mi_low=21,		# min observations/curve
		     mi_up=43,		# max observations/curve
		     F=list(F.nlin, F.nlin2),
		     Q=2,           		# two functional covariates
		     error_type=2,		# AR(1) error structure 
		     tau=0.35,		# variance of WN error in covariate
		     sig2noise=0.8,		# variance of WN error in response
		     rho=0.5,  		# number in [0,1]; if rho is small AR(1) looks like independent
		     seed=10		# seed number
		    )

Tt.data1 = datagen(# Y(t) = F.nlin(x,t) + error(t)
  n=50,			# 50 subjects
  m=81,			# 81 observations/subject
  F=list(F.nlin),
  Q=1,     			# two functional covariates
  error_type=3,		# KL + WN error structure
  tau=0.35,
  sig2noise=0.8,		# variance of WN error in response
  seed=100		# seed number
)

Tt.data2 = datagen(# Y(t) = F.nlin(x,t) + F.nlin2(x,t) + error(t)
			n=50,			# 50 subjects
			m=81,			# 81 observations/subject
			F=list(F.nlin, F.nlin2),
     			 Q=2,     			# two functional covariates
			error_type=2,		# KL + WN error structure
			tau=0.35,
			sig2noise=0.8,		# variance of WN error in response
			rho=0.5,  			# number in [0,1]; if rho is small AR(1) looks like independent
			seed=100			# seed number
		       )

null.data.dn = anova.datagen(# Y(t) = F.anova(x,t,d) + error(t)
			      n=50,			# 50 subjects
			      m=81,		# 81 observations/subject
			      F=F.anova1, 		# F(x,t) = F0(t); depend only on "t"
			      Q=1,  		# single functional covariates
			      d=0,  			# generage null model
			      error_type=1,		# Independent errorstructure
			      tau=0.35,		# variance of WN error in covariate 
			      sig2noise=0.8,		# variance of WN error in response
			      seed=10		# seed number
			     )

null.data.sp = anova.datagen(# Y(t) = F.anova(x,t,d) + error(t)
			      n=50,			# 50 subjects
			      m=81,		# 81 observations/subject
			      mi_low=21,		# min observations/subject
			      mi_up=43,		# max observations/subject
			      F = F.anova2, # F1(x1,t) + F2(x2,t)
			      Q = 2,
			      d=4,			# generate full model
			      error_type=1,		# Independent errorstructure
			      tau=0.35,		# variance of WN error in covariate 
			      sig2noise=0.8,		# variance of WN error in response
			      seed=10		# seed number
			     )

save(Tr.data.dn, Tr.data.sp, Tt.data1, Tt.data2, null.data.dn, null.data.sp, file="data.RData")
