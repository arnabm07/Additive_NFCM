library(MASS); library(mgcv); library(refund); library(fda)
data(gait); source("GFCM.r")
####################################
# Pre-processing Step:                	#
# @ n=39, m=20                        	#
# @ knee = response, hip = covariate  	#
####################################
hip = knee = NULL
for (i in 1:20){
  hip.temp = gait[i,,][,1]
  knee.temp = gait[i,,][,2]
  hip = cbind(hip, hip.temp)     		# dim(hip) = 39-by-20
  knee = cbind(knee, knee.temp)		# dim(knee) = 39-by-20
}

# sample size
n.true = 39; m = 20
n = 30; n.test = 9
t = seq(from=0, to=1, len=m)        		# Dense grids in [0,1]
trep = matrix(rep(t, n), nrow=n, byrow=TRUE)

# Plot hip and knee angle
par(mfrow=c(1,2))
plot(t,hip[1,], type="l", ylab="Hip angle (degree)", xlab="t", 
     cex.lab=1.2, lwd=1.5, ylim = c(-15,65), col="grey")
for (i in 2:39){lines(t,hip[i,], col="grey")}
lines(t,hip[19,], type="b", col="red", lwd=2)
lines(t,hip[38,], type="b", col="blue", lwd=2)
plot(t,knee[1,], type="l", ylab="Knee angle (degree)", xlab="t", 
     cex.lab=1.2, lwd=1.5, ylim = c(-0,80), col="grey")
for (i in 2:39){lines(t,knee[i,], col="grey")}
lines(t,knee[19,], type="b", col="red", lwd=2)
lines(t,knee[38,], type="b", col="blue", lwd=2)

# Split the data into training and test data set #
set.seed(10)
ind.test = sample((1:n.true), n.test, replace=FALSE)
w = hip[-ind.test,]; y = knee[-ind.test,]
xtest = hip[ind.test,]; ytest = knee[ind.test,]
data.test = list(X = xtest, Y = ytest)

#######################
# Estimation/Prediction #
#######################

# Smooth noisy covariate w by applying FPCA
w.sm = fpca.sc(w, pve=0.99, var=TRUE)
w.eval = w.sm$evalues/m
w.efunc = (w.sm$efunctions)*sqrt(m)
xhat = w.sm$Yhat                                                	# n-by-m
mu.hat = w.sm$mu                                                	# m-by-1
sig2.hat = diag(w.efunc%*%diag(w.eval)%*%t(w.efunc))	# m-by-1
xhat.tr = scale(xhat, center = mu.hat, scale = sqrt(sig2.hat))

# Fit GFCM/FCM
xhat.tr.vec = as.vector(t(xhat.tr))  			# n*m-by-1
t.vec = as.vector(t(trep))				# n*m-by-1
y.vec = as.vector(t(y))				# n*m-by-1 
GFCM.fit = gam(y.vec ~ te(xhat.tr.vec, t.vec, bs="ps", k=c(7,7)), method="REML")
FCM.fit = gam(y.vec ~ s(t.vec, bs="ps", k=7) + s(t.vec, by=xhat.tr.vec, bs="ps", k=7), method="REML") 

# Obtain fitted values
GFCM.Fstar.fit = GFCM.fit$fitted.values
FCM.Fstar.fit = FCM.fit$fitted.values

# Smooth noisy covarate in the test data
xtest.sm = fpca.sc(Y=w, Y.pred=xtest, pve=0.99, var=TRUE)$Yhat
xtest.tr = scale(xtest.sm, center = mu.hat, scale = sqrt(sig2.hat))
newdata = list(xhat.tr.vec = as.vector(t(xtest.tr)), t.vec = rep(t, nrow(xtest.tr)))
GFCM.Fstar.pred = predict(GFCM.fit, newdata=newdata)	# n.test*m-by-1
FCM.Fstar.pred = predict(FCM.fit, newdata=newdata)  	# n.test*m-by-1

# Obtain residuals
GFCM.Res = GFCM.fit$residuals			# Residuals from training data
FCM.Res = FCM.fit$residuals  			# Residuals from training data
GFCM.Resp = as.vector(t(ytest))-GFCM.Fstar.pred	# Residuals from test data
FCM.Resp = as.vector(t(ytest))-FCM.Fstar.pred  		# Residuals from test data

# Estimate RMSPE (prediction error)
GFCM.RMSPE_in = sqrt(mean(GFCM.Res^2))
GFCM.RMSPE_out = sqrt(mean(GFCM.Resp^2))
FCM.RMSPE_in = sqrt(mean(FCM.Res^2))
FCM.RMSPE_out = sqrt(mean(FCM.Resp^2))

# Estimate variance of predicted response
# GAFCM
GFCM.CovRes = G(GFCM.Res, n, m, pve=0.99)		# m-by-m
GFCM.StdF.out = Std.est(GFCM.fit, newdata, GFCM.CovRes, CovResp=NULL, n, n.test=nrow(xtest), m)
GFCM.VarFp = GFCM.StdF.out			# n.test*m-by-1

# Obtain Summary Stats obtained based on the GFCM
# (i) Compute ACP
GFCM.ICP85 = CP(ytest, GFCM.Fstar.pred, GFCM.VarFp, 0.15)  	# nominal level alpha = 0.15
GFCM.ICP90 = CP(ytest, GFCM.Fstar.pred, GFCM.VarFp, 0.1)	# nominal level alpha = 0.10
GFCM.ICP95 = CP(ytest, GFCM.Fstar.pred, GFCM.VarFp, 0.05)	# nominal level alpha = 0.05
# (ii) Compute IL
GFCM.IL= c(mean(rowMeans(2*GFCM.ICP85$MOE)), 
           mean(rowMeans(2*GFCM.ICP90$MOE)), 
           mean(rowMeans(2*GFCM.ICP95$MOE)))
# (iii) Compute range of the estimated standard errors; refer to main paper
GFCM.minSE = c(mean(apply(2*GFCM.ICP85$MOE,1,min)), 
               mean(apply(2*GFCM.ICP90$MOE,1,min)), 
               mean(apply(2*GFCM.ICP95$MOE,1,min)))
GFCM.maxSE = c(mean(apply(2*GFCM.ICP85$MOE,1,max)), 
               mean(apply(2*GFCM.ICP90$MOE,1,max)), 
               mean(apply(2*GFCM.ICP95$MOE,1,max)))
GFCM.R85 = c(GFCM.minSE[1], GFCM.maxSE[1])
GFCM.R90 = c(GFCM.minSE[2], GFCM.maxSE[2])
GFCM.R95 = c(GFCM.minSE[3], GFCM.maxSE[3])
GFCM.R = rbind(GFCM.R85, GFCM.R90, GFCM.R95)


# FCM
FCM.CovRes = G(FCM.Res, n, m, pve=0.99)	# m-by-m
FCM.StdF.out = Std.est(FCM.fit, newdata, FCM.CovRes, CovResp=NULL, n, n.test=nrow(xtest), m)
FCM.VarFp = FCM.StdF.out			# n.test*m-by-1

# Obtain Summary Stats obtained based on the GFCM
# (i) Compute ACP
FCM.ICP85 = CP(ytest, FCM.Fstar.pred, FCM.VarFp, 0.15)    	# nominal level alpha = 0.15
FCM.ICP90 = CP(ytest, FCM.Fstar.pred, FCM.VarFp, 0.1)		# nominal level alpha = 0.10
FCM.ICP95 = CP(ytest, FCM.Fstar.pred, FCM.VarFp, 0.05)		# nominal level alpha = 0.05
# (ii) Compute IL
FCM.IL= c(mean(rowMeans(2*FCM.ICP85$MOE)), 
          mean(rowMeans(2*FCM.ICP90$MOE)), 
          mean(rowMeans(2*FCM.ICP95$MOE)))
# (iii) Compute range of the estimated standard errors; refer to main paper
FCM.minSE = c(mean(apply(2*FCM.ICP85$MOE,1,min)), 
              mean(apply(2*FCM.ICP90$MOE,1,min)), 
              mean(apply(2*FCM.ICP95$MOE,1,min)))
FCM.maxSE = c(mean(apply(2*FCM.ICP85$MOE,1,max)), 
              mean(apply(2*FCM.ICP90$MOE,1,max)), 
              mean(apply(2*FCM.ICP95$MOE,1,max)))
FCM.R85 = c(FCM.minSE[1], FCM.maxSE[1])
FCM.R90 = c(FCM.minSE[2], FCM.maxSE[2])
FCM.R95 = c(FCM.minSE[3], FCM.maxSE[3])
FCM.R = rbind(FCM.R85, FCM.R90, FCM.R95)


# Above procedures can be implemented using the GFCM() function:
wlist = xtest = list(NULL)
wlist[[1]] = w; xtest[[1]] = data.test$X
newdata = list(X = xtest, Y = ytest)

GFCM.fit = GFCM(y, wlist, nbasis=list(c(7,7)), pve=0.99, fit_opt=list("nonlinear"), newdata=newdata)
FCM.fit = GFCM(y, wlist, nbasis=list(7), pve=0.99, fit_opt=list("linear"), newdata=newdata)


#################################
# Graphical analysis: levelplot #
#################################
Pred.GFCM = GFCM.fit$Fstar.pred             	# n.test*m-by-1
Pred.FCM = FCM.fit$Fstar.pred               	# n.test*m-by-1
PredMat.GFCM = matrix(Pred.GFCM, nrow = nrow(ytest), ncol=ncol(ytest), byrow=TRUE)
PredMat.FCM = matrix(Pred.FCM, nrow = nrow(ytest), ncol=ncol(ytest), byrow=TRUE)
colnames(PredMat.GFCM) = round(t,2)
rownames(PredMat.GFCM) = c("i'=1", "i'=2", "i'=3", "i'=4", "i'=5", "i'=6", "i'=7", "i'=8", "i'=9")

library(lattice)
par(mfrow=c(1,1))
levelplot(t(PredMat.GFCM), contour=TRUE,
          
          # Colorkey #
          colorkey=list(space="top"),
          at=seq(0,80,length=35), 
          
          # Color #
          col.regions = colorRampPalette(
            c("white", "gray60", "gray50", "gray30", "gray10")), 
          
          # Label #
          xlab="t", ylab="Hip angle",
          main = "",
          cex.lab=0.9)