###############################################################
# ex4_test_method2.r - August/27/2015			#
# Script created by Janet Kim				#
# Contents:						#
# (i)   test.sparse2: Bootstrap-based test on null.data.sp data	#
# @ Test H0: F(x,t) = F0(t) vs. Ha: F(x,t) = F1(x,t)		#	
###############################################################
library(MASS); library(refund); library(splines); library(mgcv)
source("test_method2.r"); load("data.RData")

test.dense = test.anova(
			  y=null.data.dn$Yanova,	# 50-by-81 
			  w=null.data.dn$Weval,	# 50-by-81
			  nbasis.null=7,		# number of null model basis 
			  nbasis.full=c(7,7),		# number of full model basis 
			  pve=0.99,		# percent of variance explained is 99% 
			  B=200,			# number of bootstrap replication 
			  seed.B=c(1:200)
		    )
