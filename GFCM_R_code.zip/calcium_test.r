rm(list=ls())
library(MASS); library(mgcv); library(refund); library(fda)

####################################
# Pre-processing Step:                	#
# @ Should be implemented in MATLAB#
# @ calcium absorption = response     	#
# @ calcium intake = covariate        	#
####################################
% Sparsely Sampled Design (do not smooth the response)
p = 'SPECIFY THE PATH WHERE YOU SAVED CALCIUM DATA';
addpath(p);

% calcium = [id | age | calabs |caldiet|bsa]
calcium = dlmread('calcium.csv', ',', 'A2..G528');
id = calcium(:,1);
iid = sort(unique(id));
ytrue = calcium(:,3);                           % calcium absorption
wtrue = calcium(:,4);                          % calcium intake
ztrue = calcium(:,7);                           % bmi.mean
age = calcium(:,2);                              % length(unique(age)) = 249 = m


% Transformation of time points; From [a,b] to [0,1]
A = [max(age) 1 ; min(age) 1]; 
b = [1 0];
c = A\b';
transAge = [age ones(length(age),1)];   % dim(transAge) = 527-by-2
trep = transAge*c;                          	% length(trep) = 527
t = unique(trep);

% Pre-process the data; n=188, m=249
n = length(unique(id));
m = length(t);
i_len = [];                                 	% element in each cell
ycell = cell(1, n); 
wcell = cell(1, n);
zcell = cell(1, n);
tcell = cell(1, n);
for i = 1:n
ind = find(id==i);
ycell{i} = ytrue(ind)';
wcell{i} = wtrue(ind)';
zcell{i} = ztrue(ind)';
tcell{i} = trep(ind)';
i_len = [i_len length(ind)];
end
y = cell2mat(ycell);
z = cell2mat(zcell);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform PCA on noisy covariate W(t) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pm = setOptions('regular',0, 'selection_k', 'FVE', 'FVE_threshold',0.99, 'corrPlot',0,'rho', -1,'verbose','off'); 
[w_sm] = FPCA(wcell, tcell, pm);
w_efunc = getVal(w_sm,'phi');                           % eigenfunction
w_eval = getVal(w_sm, 'lambda');                        % eigenvalues
xhat_full = getVal(w_sm, 'y_pred');
xhat_orig = getVal(w_sm, 'y_predOrig');
xhat = cell2mat(xhat_orig);                             % length(xhat) = 527
w_muhat = getVal(w_sm, 'mu');                           % sample mean of length(w_muhat) = 249
w_sig2hat = reshape(diag(w_efunc*diag(w_eval)*w_efunc'),1, size(w_efunc,1));

% Point-wise transformation of Xhat_full
xhat_tr_full_cell = cell(1,n);
for i = 1:n
xhat_tr_full_cell{i} = (xhat_full{i} - w_muhat) ./ sqrt(w_sig2hat);
end
xhat_tr_full = cell2mat(xhat_tr_full_cell);

% Re-order w_muhat and w_sig2hat
% ind_t_cell{1} = [91 145 197]; ... ; ind_t_cell{188} = [151 204]
ind_t_cell =  cell(1,n);
for i = 1: n
ind_t_temp = [];
for ii = 1:length(tcell{i})
ind_t_temp = [ind_t_temp find(t == tcell{i}(ii))];
ind_t_cell{i} = ind_t_temp;
end
end
ind_t = cell2mat(ind_t_cell);               		% length(ind_t) = 527
w_mu_ord = w_muhat(ind_t);                  	% length(w_mu_ord) = 527
w_sig2_ord = w_sig2hat(ind_t);              	% length(w_sig2_ord) = 527
xhat_tr = (xhat - w_mu_ord) ./  sqrt(w_sig2_ord); % point-wise transf; length(xhat_tr) = 527

% Save (y, xhat_tr, trep)
cd(p);
save('y.txt', 'y', '-ascii')
save('xhat_tr.txt', 'xhat_tr', '-ascii')
save('trep.txt', 'trep', '-ascii')
save('t.txt', 't', '-ascii')
save('z.txt', 'z', '-ascii')

% Go to R; Using the pre-processed data, fit null and full models

#################################
#Fit null and full models       #
# @ Should be implemented in R  #
#################################
n = 188
y <- unname(unlist((read.table("y.txt"))))
xhat.tr <- unname(unlist((read.table("xhat_tr.txt"))))
z <- unname(unlist((read.table("z.txt"))))
z.tr = as.vector(scale(z, center=mean(z), scale=sd(z)))
trep <- unname(unlist((read.table("trep.txt"))))
                         
# Fit null and full model
fit.null = gam(y~s(trep, by=z.tr, bs="ps", k=7), method="REML")
fit.full = gam(y~s(trep, bs="ps", k=7) + te(xhat.tr, trep, bs="ps", k=c(7,7))+s(trep, by=z.tr, bs="ps", k=7), method="REML")
Fstarfit.null = fit.null$fitted.values    # will be used to generate bootstrap datasets
Res = fit.full$residuals                  # will be used to generate bootstrap datasets

# Save r.GFCM / r.FCM and rp.GFCM / rp.FCM
write.csv(Res, file = "Res.csv")
write.csv(z.tr, file = "ztr.csv")
                         
# Anova test
test = anova.gam(fit.null, fit.full, freq=TRUE, test="F", p.type=0)
Fst = test$F[2]

% Go to MATLAB; Generate bootstrap data

#######################################
# Generate bootstrap data             #
# @ Should be implemented in MATLAB   #
#######################################
Res = dlmread('Res.csv', ',', 1,1); % length(Res) = 527
% Save observed points in the i-th curve to i-th cell
Res_temp = Res;
xhat_temp = xhat_tr;
Res_cell = cell(1, n); 
xhat_tr_cell = cell(1,n);
for i = 1:n
Res_cell{i} = Res_temp(1:i_len(i))';    % Residual obtained from the original data
xhat_tr_cell{i} =  xhat_temp(1:i_len(i)); 
Res_temp(1:i_len(i)) = [];
xhat_temp(1:i_len(i)) = [];
end

% Bootstrap the residual
B = 250;
tB = cell(1,B);				% tB{b} = [ array-1 ] for b=1,2, ..., 250
ResB_total = cell(1,B);
xhatB_total = cell(1,B);
cell_len = cell(1,B); 
tB_len = [];
for b = 1:B
rng(b*100)
bs_ind = randsample(n, n, 'true')';
tB_temp = cell(1,n);
ResB_temp = cell(1,n);
xhatB_temp = cell(1,n);
for i = 1:n
tB_temp{i} = tcell{bs_ind(i)};
ResB_temp{i} = Res_cell{bs_ind(i)};
xhatB_temp{i} = xhat_tr_cell{bs_ind(i)};
end
cell_len{b} = cellfun('length', tB_temp);
tB{b} = cell2mat(tB_temp);
ResB_total{b} = cell2mat(ResB_temp);
xhatB_total{b} = cell2mat(xhatB_temp);
tB_len = [tB_len length(tB{b})];        % tB_len = 531, 543, ..., 532; length(tB_len) = B
end

tB_ALL = cell2mat(tB);                  % length(tB_ALL) = sum(tB_len)
ResB_ALL = cell2mat(ResB_total);        % length(ResB_ALL) = sum(tB_len)
xhatB_tr_subALL = cell2mat(xhatB_total);% length(xhatB_tr_subALL) = sum(tB_len)
cell_lenALL = cell2mat(cell_len);

save('tB_len.txt', 'tB_len', '-ascii')
save('tB_ALL.txt', 'tB_ALL', '-ascii')
save('ResB_ALL.txt', 'ResB_ALL', '-ascii')
save('xhatB_tr_subALL.txt', 'xhatB_tr_subALL', '-ascii')
save('cell_lenALL.txt', 'cell_lenALL', '-ascii')

% Go to R

#################################
# Perform resampling based test #
# @ Should be implemented in R  #
#################################
B = 250
tB_len <- unname(unlist((read.table("tB_len.txt"))))
tB_ALL <- unname(unlist((read.table("tB_ALL.txt"))))
ResB_ALL <- unname(unlist((read.table("ResB_ALL.txt"))))  # Bootstrap residuals
xhatB_tr_subALL <- unname(unlist((read.table("xhatB_tr_subALL.txt"))))
cell_len <- matrix(unname(unlist((read.table("cell_lenALL.txt")))), nrow=B, ncol=n, byrow=TRUE)

# Data processing for BMI
ztrB_uq <- NULL
for(i in 1:(length(z.tr)-1)){
  if (z.tr[i] != z.tr[i+1]){ ztrB_uq = c(ztrB_uq, z.tr[i]) }
}
ztrB_uq = c(ztrB_uq, z.tr[length(z.tr)])
ztrB <- as.list(NULL)
for (b in 1:B){
  temp <- NULL
  for (i in 1:n){ temp <- c(temp, rep(ztrB_uq[i], cell_len[b,i])) }
  ztrB[[b]] <- temp
}

# Data processing for CA intake and observed time points
tB = ResB = xhatB.tr = as.list(NULL)
tB_temp = tB_ALL; ResB_temp = ResB_ALL; xhatB_temp = xhatB_tr_subALL
for (i in 1:B){
  sub = 1:tB_len[i]
  tB[[i]] = tB_temp[sub]
  ResB[[i]] = ResB_temp[sub]
  xhatB.tr[[i]] = xhatB_temp[sub]
  tB_temp = tB_temp[-sub]; ResB_temp = ResB_temp[-sub]; xhatB_temp = xhatB_temp[-sub]
}

FstB = NULL; count.naB = 0
# Bootstrap
for (b in 1:B){
  print(b)  
  # Reconstruct bootstrap datasets
  yB = predict(fit.null, newdata=list(trep=tB[[b]], z.tr=ztrB[[b]])) + ResB[[b]]
  
  # fit null and full model using the bootstrap data
  fit.nullB = gam(yB~s(tB[[b]], by=ztrB[[b]], bs="ps", k=7), method="REML")
  fit.fullB = gam(yB~s(tB[[b]], bs="ps", k=7) + te(xhatB.tr[[b]], tB[[b]], bs="ps", k=c(7,7)) +
                  s(tB[[b]], by=ztrB[[b]], bs="ps", k=7), method="REML")
  
  # Anova test
  testB = anova.gam(fit.nullB, fit.fullB, freq=TRUE, test="F", p.type=0)
  print(testB$Deviance[2])
  if (testB$Deviance[2] <= 0){ FstB=c(FstB, 0); count.naB = count.naB+1 }
  if (testB$Deviance[2] > 0){ FstB=c(FstB, testB$F[2]); count.naB = count.naB }  
}
pvalue = mean(Fst<FstB)
pvalue