######################################################
# ex2_GFCM.r - August/27/2015			#
# Script created by Janet Kim			#
# Contents:					#
# (i)   GFCM.dense: model GFCM using Tr.data.dn data 	#
# (ii)  FCM.sparse: model linear FCM using Tr.data.sp data	#
######################################################
library(MASS); library(refund); library(splines); library(mgcv)
source("GFCM.r"); load("data.RData")

GFCM.dense = GFCM(
		   y=Tr.data.dn$Yeval,				# 50-by-81
		   w=Tr.data.dn$Weval,				# 50-by-81
		   nbasis=list(c(7,7)),				# K_x=7 basis for "x"; K_t=7 basis for "t"
		   pve=0.99,					# percentage of variance explained is 99%
		   fit_opt=list("nonlinear"),				# model GFCM
		   opt="gam",
		   newdata=list(X=Tt.data1$Xfull, Y=Tt.data1$Yfull)	# test data set
		  )


GFCM.sparse = GFCM(
		   y=Tr.data.sp$Yeval,				# 50-by-81 with some "NA"s in element
		   w=Tr.data.sp$Weval,				# 50-by-81 with some "NA"s in element
		   nbasis=list(c(7,7), c(7,7)),				# K_t=7 basis for "t"
		   pve=0.99,					# percentage of variance explained is 99%
		   fit_opt=list("nonlinear", "nonlinear"),			# model GFCM
	           	   opt="bam",
		   newdata=list(X=Tt.data2$Xfull, Y=Tt.data2$Yfull)	# test data set
		  )