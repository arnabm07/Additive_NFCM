##############################################################
# ex3_test.r - August/27/2015				#
# Script created by Janet Kim				#
# Contents:						#
# (i)   test.dense: Bootstrap-based test on null.data.dn data	#
# (ii)  test.sparse: Bootstrap-based test on null.data.sp data	#
# @ Test H0: F(x,t) = F0(t) vs. Ha: F(x,t) = F1(x,t)		#	
###############################################################
library(MASS); library(refund); library(splines); library(mgcv)
source("test.r"); load("data.RData")

test.dense = test.anova(
			y=null.data.dn$Yanova,		# 50-by-81
			w=null.data.dn$Weval,		# 50-by-81 
			test.type = 1,
			nbasis.null=7,			# number of null model basis 
			nbasis.full=c(7,7),			# number of full model basis 
			pve=0.99,				# percent of variance explained is 99% 
			B=200,				# number of bootstrap replication 
			seed.B=c(1:200),
		  	l=1)


test.sparse = test.anova(
			y=null.data.sp$Yanova,		# 50-by-81 with some "NA"s in element
			w=null.data.sp$Weval,		# 50-by-81 with some "NA"s in element
			test.type = 2,
			nbasis.null=7,			# number of null model basis 
			nbasis.full=c(7,7),			# number of full model basis 
			pve=0.99,				# percent of variance explained is 99% 
			B=200,				# number of bootstrap replication 
			seed.B=c(1:200),
		 	l=1)