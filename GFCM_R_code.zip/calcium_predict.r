library(MASS); library(mgcv); library(refund); library(fda)
source("GFCM.r")
####################################
# Pre-processing Step:                	#
# @ Should be implemented in MATLAB#
# @ calcium absorption = response     	#
# @ calcium intake = covariate        	#
####################################
p = 'SPECIFY THE PATH WHERE YOU SAVED CALCIUM DATA';
addpath(p);

% calcium = [id | age | calabs |caldiet|bsa]
calcium = dlmread('calcium.csv', ',', 'A2..G528');
id = calcium(:,1);
iid = sort(unique(id));
ytrue = calcium(:,3);                           % calcium absorption
wtrue = calcium(:,4);                          % calcium intake
ztrue = calcium(:,7);                           % bmi.mean
age = calcium(:,2);                              % length(unique(age)) = 249 = m

% Transformation of time points; From [a,b] to [0,1]
A = [max(age) 1 ; min(age) 1]; 
b = [1 0];
c = A\b';
transAge = [age ones(length(age),1)];	% dim(transAge) = 527-by-2
trep = transAge*c;                                % length(trep) = 527
t_unique = unique(trep);                      % length(t_unique) = 249

% Initial Setting
ntrue = length(unique(id));           	% ntrue=188
m = length(t_unique);                          % m = 249
ycell = cell(1, ntrue); 
wcell = cell(1, ntrue); 
zcell = cell(1, ntrue);
tcell = cell(1, ntrue);

% Save i-th curve in i-th cell
for i = 1:ntrue
ind = find(id==i);
ycell{i} = ytrue(ind)';
wcell{i} = wtrue(ind)';
zcell{i} = ztrue(ind)';
tcell{i} = trep(ind)';
end

% Create test data
% Begin with 100 cells and drop cells with only 1 measurement
ntest_temp = 100;
rng(919);
ind_test_temp = randsample(iid, ntest_temp);
ytest_celltemp = cell(1, ntest_temp); 
wtest_celltemp = cell(1, ntest_temp); 
ztest_celltemp = cell(1, ntest_temp); 
ttest_celltemp = cell(1, ntest_temp);

i_len = [];
for i = 1:ntest_temp
ytest_celltemp{i} = ycell{ind_test_temp(i)};
wtest_celltemp{i} = wcell{ind_test_temp(i)};
ztest_celltemp{i} = zcell{ind_test_temp(i)};
ttest_celltemp{i} = tcell{ind_test_temp(i)};
i_len = [i_len length(ytest_celltemp{i})];
end
ii = find(i_len~=1);  % ii select the cell with length greater than 1
ind_test = ind_test_temp(ii);

ntest = 40;           % number of subject in test data
ytest_cell = cell(1, ntest); 
wtest_cell = cell(1, ntest); 
ztest_cell = cell(1, ntest); 
ttest_cell = cell(1, ntest);
for i = 1:ntest
ytest_cell{i} = ycell{ind_test(i)};
wtest_cell{i} = wcell{ind_test(i)};
ztest_cell{i} = wcell{ind_test(i)};
ttest_cell{i} = tcell{ind_test(i)};
end
ttest = cell2mat(ttest_cell);            	% length(ttest) = 126
ttest_unique = unique(ttest);               % length(ttest_unique) = 104

% For each i, find an index such that ttest(i) == ttest_unique(ind_tt); save ind_tt
ind_tt =  [];
for i = 1: length(ttest)
ind_tt = [ind_tt find(ttest_unique == ttest(i))];
end

% Create training data
n = ntrue-ntest;           		% number of subject in training data
for i = 1:ntest
ycell{ind_test(i)} = [ ];
wcell{ind_test(i)} = [ ];
zcell{ind_test(i)} = [ ];
tcell{ind_test(i)} = [ ];
end
y_cell = ycell(~cellfun('isempty', ycell));
w_cell = wcell(~cellfun('isempty', wcell));
z_cell= zcell(~cellfun('isempty', zcell));
t_cell = tcell(~cellfun('isempty', tcell));
t = cell2mat(t_cell);               	% length(t) = 401
ttr_unique = unique(t);        		% length(ttr_unique) = 221

% For each i, find an index such that t(i) == ttr_unique(ind_t); save ind_t
ind_t =  [];
for i = 1: length(t)
ind_t = [ind_t find(ttr_unique == t(i))];
end

addpath('SPECIFY THE PATH WHERE YOU SAVED PACE PACKAGE');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform PCA on training data %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pm1 = setOptions('regular',0, 'selection_k', 'FVE', 'FVE_threshold',0.99,'corrPlot',0,'rho', -1,'verbose','off'); 
[ww1] = FPCA(w_cell, t_cell, pm1);
w_efunc = getVal(ww1,'phi');                      % dim(w_efunc) = 221-by-3
w_eval = getVal(ww1, 'lambda'); 
w_muhat = getVal(ww1, 'mu');                    % length(w_muhat) = 221
w_sig2hat = reshape(diag(w_efunc*diag(w_eval)*w_efunc'),1, size(w_efunc,1));  % length(w_sig2hat) = 221
xhat_orig = getVal(ww1, 'y_predOrig');        % Predicted value evalueated at "t_cell"
xhat = cell2mat(xhat_orig);                         % length(xhat) = 401

% Re-order w_muhat and w_sig2hat
w_mu_ord = [];
w_sig_ord = [];
for i = 1:length(xhat)
w_mu_ord = [w_mu_ord w_muhat(ind_t(i))];          % length(w_mu_ord) = 401
w_sig_ord = [w_sig_ord sqrt(w_sig2hat(ind_t(i)))];  % length(w_sig_ord) = 401
end
% Center/scaling transformation of the training data set
xhat_tr = (xhat - w_mu_ord) ./  w_sig_ord;          % length(xhat_tr) = 401

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform PCA on test data %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wtestALL_cell = FPCApred(ww1, wtest_cell, ttest_cell);
wtestALL = cell2mat(wtestALL_cell);                 % length(wtestALL) = 126

pm1_test = setOptions('regular',0, 'selection_k', 'FVE', 'FVE_threshold',0.99, 'newdata', ttest_unique, ...
                      'corrPlot',0,'rho', -1,'verbose','off'); 
[ww1_test] = FPCA(w_cell, t_cell, pm1_test);
w_muhat_test = getVal(ww1_test, 'mu');            % length(w_muhat_test) = 104
w_efunc_test = getVal(ww1_test,'phi');              % dim(w_efunc_test) = 104-by-3
w_eval_test = getVal(ww1_test, 'lambda'); 
w_sig2hat_test = reshape(diag(w_efunc_test*diag(w_eval_test)*w_efunc_test'),1, size(w_efunc_test,1));  % length(w_sig2hat) = 221
                              
% Re-order w_muhat and w_sig2hat
w_mu_ord_test = [];
w_sig_ord_test = [];
for i = 1:length(wtestALL)
w_mu_ord_test = [w_mu_ord_test w_muhat_test(ind_tt(i))];          % length(w_mu_ord_test) = 126
w_sig_ord_test = [w_sig_ord_test sqrt(w_sig2hat_test(ind_tt(i)))];  % length(w_sig_ord_test) = 126
end
% Center/scaling transformation of the test data set
wtestALL_tr = (wtestALL - w_mu_ord_test) ./  w_sig_ord_test;
                              
% Save data
ytest = cell2mat(ytest_cell);   % length(ytest) = 126
wtest = cell2mat(wtest_cell);
ztest = cell2mat(ztest_cell);
ttest = cell2mat(ttest_cell);
y = cell2mat(y_cell);          	 % length(y) = 401
w = cell2mat(w_cell);
z = cell2mat(z_cell);
t= cell2mat(t_cell);
cd(p);
save('ytest.txt', 'ytest', '-ascii')
save('ttest.txt', 'ttest', '-ascii')
save('wtestALL_tr.txt', 'wtestALL_tr', '-ascii')
save('ztest.txt', 'ztest', '-ascii')
save('y.txt', 'y', '-ascii')
save('t.txt', 't', '-ascii')
save('xhat_tr.txt', 'xhat_tr', '-ascii')
save('z.txt', 'z', '-ascii')
save('ind_test.txt', 'ind_test', '-ascii')
                              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FPCA based on tD for reconstruction of test data set          	%
% Reconstruct a design matrix based on test data observed at tD 	%
% Reconstruct new response defined over tD                      	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tD = linspace(0,1,101); % Define dense grids
pm1D = setOptions('regular',0, 'selection_k', 'FVE', 'FVE_threshold',0.99, 'newdata', tD,...
                  'corrPlot',0,'rho', -1,'verbose','off'); 
[ww1D] = FPCA(w_cell, t_cell, pm1D);
w_efuncD = getVal(ww1D,'phi');                          % dim(w_efuncD) = 101-by-3
w_evalD = getVal(ww1D, 'lambda'); 
w_muhatD = getVal(ww1D, 'mu');                        % length(w_muhatD) = 101
w_sig2hatD = reshape(diag(w_efuncD*diag(w_evalD)*w_efuncD'),1, size(w_efuncD,1));  % length(w_sig2hatD) = 101

% FPCA based on tD in test data set
[wDpred, xi_new, xi_var] = FPCApred(ww1D, wtest_cell, ttest_cell); 
w_muD_test = reshape( repmat(w_muhatD, 1, ntest), length(tD), ntest)';  % ntest-by-101
wtestD = w_muD_test+(xi_new*w_efuncD');          % ntest-by-101
% Center/scaling transformation of the test data set
w_sigD_test = reshape(repmat(sqrt(w_sig2hatD), 1, ntest), length(tD), ntest)';  % ntest-by-101 
wDmat = (wtestD - w_muD_test) ./  w_sigD_test;  % ntest-by-101

[yy1Dtest] = FPCA(ytest_cell, ttest_cell, pm1D);
ytestD_cell = FPCAeval(yy1Dtest, 1:ntest, tD);
ytestD = cell2mat(ytestD_cell);                         	  % ntest_by-101

% Save data
cd(p);
save('ytestD.txt', 'ytestD', '-ascii')
save('wDmat.txt', 'wDmat', '-ascii')

# Go to R; Fit GFCM/FCM

###################################
# Fit the model and obtain residuals  #
# @ Should be implemented in R        #
###################################
n = 188-40; ntest = 40
ytest <- unname(unlist((read.table("ytest.txt"))))                	# 126-by-1
wtestALL.tr <- unname(unlist((read.table("wtestALL_tr.txt"))))    	# 126-by-1
ztest <- unname(unlist((read.table("ztest.txt"))))                	# 126-by-1
ttest <- unname(unlist((read.table("ttest.txt"))))                	# 126-by-1
y <- unname(unlist((read.table("y.txt"))))                        		# 401-by-1
t <- unname(unlist((read.table("t.txt"))))                        		# 401-by-1
xhat.tr <- unname(unlist(as.matrix((read.table("xhat_tr.txt"))))) 	# 401-by-1
z <- unname(unlist((read.table("z.txt"))))                        		# 401-by-1
xhat.tr <- t(xhat.tr)

z.tr = as.vector(scale(z, center=mean(z), scale=sd(z)))
ztest.tr = as.vector(scale(ztest, center=mean(z), scale=sd(z)))
# Fit the GFCM/FCM
#GFCM.fit = gam(y ~ te(xhat.tr, t, bs="ps", k=c(7,7)), method="REML")
#FCM.fit = gam(y ~ s(t, bs="ps", k=7) + s(t, by=xhat.tr, bs="ps", k=7), method="REML") 
GFCMmult.fit = gam(y ~ te(xhat.tr, t, bs="ps", k=c(7,7)) + 
                   s(t, by=z.tr, bs="ps", k=7), method="REML")
FCMmult.fit = gam(y ~ s(t, bs="ps", k=7) + s(t, by=xhat.tr, bs="ps", k=7) + 
                  s(t, by=z.tr, bs="ps", k=7), method="REML") 

# Obtain fitted values
Fstar.GFCMmult = GFCMmult.fit$fitted.values
Fstar.FCMmult = FCMmult.fit$fitted.values

# Do prediction using the transformed test data
newdata = list(xhat.tr = wtestALL.tr, z.tr = ztest.tr, t = ttest)
GFCMmultpred = predict(GFCMmult.fit, newdata=newdata)
FCMmultpred = predict(FCMmult.fit, newdata=newdata)

# Obtain residuals
r.GFCMmult = GFCMmult.fit$residuals                           	# length(r.GFCM) = 401
r.FCMmult = FCMmult.fit$residuals                    		# length(r.FCM) = 401
rp.GFCMmult = ytest - GFCMmultpred                            	# length(rp.GFCM) = 126
rp.FCMmult = ytest - FCMmultpred                              	# length(rp.FCM) = 126

# Save r.GFCM / r.FCM and rp.GFCM / rp.FCM
write.csv(r.GFCMmult, file = "r_GFCMmult.csv")
write.csv(r.FCMmult, file = "r_FCMmult.csv")

####################
# Prediction Error #
####################
RMSE.GFCMmult = sqrt(mean(r.GFCMmult^2)); RMSE.GFCMmult
RMSEp.GFCMmult = sqrt(mean(rp.GFCMmult^2)); RMSEp.GFCMmult
RMSE.FCMmult = sqrt(mean(r.FCMmult^2)); RMSE.FCMmult
RMSEp.FCMmult = sqrt(mean(rp.FCMmult^2)); RMSEp.FCMmult


#############################################
# Prediction over tD                        		#
# Will be used to obtain pred bands over tD 	#
#############################################
tD <- seq(0,1, len=101); tDrep = rep(tD, ntest)
ytestD <- unname(unlist((read.table("ytestD.txt"))))  # ntest*101-by-1
ytestDmat <- matrix(ytestD, ntest, length(tD))
wDmat <- unname(unlist((read.table("wDmat.txt"))))    	# ntest*101-by-1
wDmat <- matrix(wDmat, ntest, length(tD))
wD <- as.vector(t(wDmat))                             		# ntest*101-by-1
zD <- read.csv("bmi_meanD.csv", header=TRUE)[,2]
zD.tr <- scale(zD, center=mean(z), scale=sd(z))
newdata2 =list(xhat.tr = wD, z.tr = zD.tr, t = tDrep)
GFCM.predD = predict(GFCMmult.fit, newdata=newdata2) # ntest*101-by-1
FCM.predD = predict(FCMmult.fit, newdata=newdata2)	# ntest*101-by-1

# Save design matrix / hat matrix
Z_GFCM = model.matrix(GFCMmult.fit)                       	# 401-by-56
Xp_GFCM = predict(GFCMmult.fit, newdata=newdata2, type="lpmatrix")
H_GFCM = vcov(GFCMmult.fit, dispersion=1)                 	# 56-by-56
Z_FCM = model.matrix(FCMmult.fit)                              	# 401-by-15
Xp_FCM = predict(FCMmult.fit, newdata=newdata2, type="lpmatrix")
H_FCM = vcov(FCMmult.fit, dispersion=1)                        	# 15-by-15
write.csv(Z_GFCM, file = "Z_GFCM.csv")
write.csv(Xp_GFCM, file = "Xp_GFCM.csv")
write.csv(H_GFCM, file = "H_GFCM.csv")
write.csv(Z_FCM, file = "Z_FCM.csv")
write.csv(Xp_FCM, file = "Xp_FCM.csv")
write.csv(H_FCM, file = "H_FCM.csv")

# Go to matlab; peform PCA on residuals; estimate standard error of Fhat

#############################################
# Obtain variance of predicted response over tD #
# @ Should be implemented in MATLAB             	#
#############################################
% Call residuals
r_GFCMread = dlmread('r_GFCMmult.csv', ',', 1,1);
r_FCMread = dlmread('r_FCMmult.csv', ',', 1,1);
r_GFCM = r_GFCMread';       % length(r_GFCM) = 401
r_FCM = r_FCMread';         % length(r_FCM) = 401

% Save residuals for each subj in cell
tr_len = cellfun(@length, xhat_orig);           % size of each cell = 1:4
r_GFCM_cell = cell(1, n); 
r_FCM_cell = cell(1, n); 
for i = 1:n
r_GFCM_cell{i} = r_GFCM(1:tr_len(i));
r_FCM_cell{i} = r_FCM(1:tr_len(i)); 
r_GFCM(1:tr_len(i)) = []; 
r_FCM(1:tr_len(i)) = [];
end

% Covariance of residuals in GFCM 
% Perform PCA on r.GFCM; estimate the covariance matrix corresp. to observed time points.
pm_r = setOptions('regular',0, 'selection_k', 'FVE', 'FVE_threshold',0.99,'corrPlot',0,'rho', -1,'verbose','off'); 
[rr] = FPCA(r_GFCM_cell, t_cell, pm_r);
rr_efunc = getVal(rr,'phi');
rr_eval = getVal(rr, 'lambda');
rr_sigma2 = getVal(rr, 'sigma');
% Perform PCA on r.GFCM; estimate the covariance matrix corresp. to new time points (tD).
pm_r_new = setOptions('regular',0, 'selection_k', 'FVE', 'FVE_threshold',0.99, 'newdata', tD, ...
'corrPlot',0,'rho', -1,'verbose','off'); 
[rr_new] = FPCA(r_GFCM_cell, t_cell, pm_r_new);
rr_efunc_new = getVal(rr_new,'phi');        % 101-by-1
rr_eval_new = getVal(rr_new, 'lambda');  % equal to rr_eval
rr_sigma2_new = getVal(rr_new, 'sigma'); % equal to rr_sigma2

% For each subject i, collect estimated eigenfunctions evaluated at observed time points.
rr_ind_t = ind_t;
rr_efunc_cell = cell(1, n);
for i = 1:n
sub_ind = rr_ind_t(1:tr_len(i));
rr_efunc_cell{i} = rr_efunc(sub_ind,:);
rr_ind_t(1:tr_len(i)) = [];
end

% Finally, we obtain 2 results:
% @ G2_GFCM: m_i-by_m_i dimensional covariance matrix evaluated at observed time points.
% @ G1_GFCM: 101-by-101 dimensional covariance matrix evaluated at new time points (tD).
G2_GFCM = cell(1, n);
for i = 1:n
G2_GFCM{i} = rr_efunc_cell{i}*diag(rr_eval)*rr_efunc_cell{i}'+rr_sigma2*eye(size(rr_efunc_cell{i},1)); 
end
G1_GFCM = rr_efunc_new*diag(rr_eval_new)*rr_efunc_new'+rr_sigma2_new*eye(size(tD,2)); % 101-by-101

% Covariance of residuals in FCM 
% Perform PCA on r.FCM; estimate the covariance matrix corresp. to observed time points.
[rr2] = FPCA(r_FCM_cell, t_cell, pm_r);
rr2_efunc = getVal(rr2,'phi');      	% 211-by-4
rr2_eval = getVal(rr2, 'lambda');
rr2_sigma2 = getVal(rr2, 'sigma');

% Perform PCA on r.FCM; estimate the covariance matrix corresp. to new time points (tD).
[rr2_new] = FPCA(r_FCM_cell, t_cell, pm_r_new);
rr2_efunc_new = getVal(rr2_new,'phi');	% 101-by-4
rr2_eval_new = getVal(rr2_new, 'lambda');
rr2_sigma2_new = getVal(rr2_new, 'sigma');

% For each subject i, collect estimated eigenfunctions evaluated at observed time points.
rr_ind_t = ind_t;
rr2_efunc_cell = cell(1, n);
for i = 1:n
sub_ind = rr_ind_t(1:tr_len(i));
rr2_efunc_cell{i} = rr2_efunc(sub_ind,:);
rr_ind_t(1:tr_len(i)) = [];
end

% Finally, we obtain 2 results:
% @ G2_FCM: m_i-by_m_i dimensional covariance matrix evaluated at observed time points.
% @ G1_FCM: 101-by-101 dimensional covariance matrix evaluated at new time points (tD).
G2_FCM = cell(1, n);
for i = 1:n
G2_FCM{i} = rr2_efunc_cell{i}*diag(rr2_eval)*rr2_efunc_cell{i}'+rr2_sigma2*eye(size(rr2_efunc_cell{i},1)); 
end
G1_FCM = rr2_efunc_new*diag(rr2_eval_new)*rr2_efunc_new'+rr2_sigma2_new*eye(size(tD,2)); % 101-by-101

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimate standard error of Fhat %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
Z_GFCM = dlmread('Z_GFCM.csv', ',', 1,1);          	% dim(Z_GFCM) = 401-by-56
Xp_GFCM = dlmread('Xp_GFCM.csv', ',', 1,1);       	% dim(Xp_GFCM) = ntest*101-by-56
H_GFCM = dlmread('H_GFCM.csv', ',', 1, 2);     	% dim(H_GFCM) = 56-by-56
Z_FCM = dlmread('Z_FCM.csv', ',', 1,1);             	% dim(Z_FCM) = 401-by-15
Xp_FCM = dlmread('Xp_FCM.csv', ',', 1,1);          % dim(Xp_FCM) = ntest*101-by-15
H_FCM = dlmread('H_FCM.csv', ',', 1, 1);                   % dim(H_FCM) = 15-by-15
sandwich1 = 0;
sandwich2 = 0;
Z1 = Z_GFCM;
Z2 = Z_FCM;
for i= 1:n
mi_len = 1:tr_len(i);
Cov.temp1 = Z1(mi_len,:)'*G2_GFCM{i}*Z1(mi_len,:);
Cov.temp2 = Z2(mi_len,:)'*G2_FCM{i}*Z2(mi_len,:);
sandwich1 = sandwich1 + Cov.temp1;         % 56-by-56
sandwich2 = sandwich2 + Cov.temp2;         % 15-by-15
Z1(mi_len,:) = [];
Z2(mi_len,:) = [];
end

% GFCM result
GG1_GFCM = diag(G1_GFCM);                       	% 101-by-1
CovTheta1 = H_GFCM*sandwich1*H_GFCM';   	% Est.of Cov(Theta); 56-by-56
VarF1 =  diag(Xp_GFCM*CovTheta1*Xp_GFCM');  	% Est.of Var(Fhat); ntest*101-by-1
VarFp1 = repmat(GG1_GFCM,ntest,1) + VarF1;    % ntest*101-by-1
              
% FCM result
GG1_FCM = diag(G1_FCM);                         % 101-by-1
CovTheta2 = H_FCM*sandwich2*H_FCM';             	% Est.of Cov(Theta); 15-by-15
VarF2 =  diag(Xp_FCM*CovTheta2*Xp_FCM');        % Est.of Var(Fhat); ntest*101-by-1
VarFp2 = repmat(GG1_FCM,ntest,1) + VarF2;       % ntest*101-by-1
save('VarFp1.txt', 'VarFp1', '-ascii')
save('VarFp2.txt', 'VarFp2', '-ascii')
                            
# Go to R; obtain prediction bands

####################################
# Variance for prediction             	#
# @ Should be implemented in R        	#
# 1) Reconstruc the data over tD.     	#
# 2) Call the reconstructed data.     	#
# 3) Apply GFCM/FCM to get residuals. #
####################################
# Call Var(Fhat_pred) from matlab
GFCM.VarFp = unname(unlist((read.table("VarFp1.txt"))))        # ntest*101
FCM.VarFp = unname(unlist((read.table("VarFp2.txt"))))          # ntest*101

# GFCM:
# 1st arg in CP: ytestDmat with dimension ntest-by-101
# 2nd arg in CP: GFCM.predD with dimension ntest*101-by-1
# 3rd arg in CP: VarFp.GFCM with dimension ntest*101-by-1
GFCM.ICP85 = CP(ytestDmat, GFCM.predD, GFCM.VarFp, 0.15)
GFCM.ICP90 = CP(ytestDmat, GFCM.predD, GFCM.VarFp, 0.1)
GFCM.ICP95 = CP(ytestDmat, GFCM.predD, GFCM.VarFp, 0.05)
GFCM.ICPall = c(GFCM.ICP85$ICP, GFCM.ICP90$ICP, GFCM.ICP95$ICP)
round(GFCM.ICPall,3) 

GFCM.IL= c(mean(rowMeans(2*GFCM.ICP85$MOE)), 
	         mean(rowMeans(2*GFCM.ICP90$MOE)), 
           mean(rowMeans(2*GFCM.ICP95$MOE)))
round(GFCM.IL, 3)

# range of SE; refer to main paper
GFCM.minSE = c(mean(apply(2*GFCM.ICP85$MOE,1,min)), 
	       mean(apply(2*GFCM.ICP90$MOE,1,min)), 
               mean(apply(2*GFCM.ICP95$MOE,1,min))) 
GFCM.maxSE = c(mean(apply(2*GFCM.ICP85$MOE,1,max)), 
	       mean(apply(2*GFCM.ICP90$MOE,1,max)), 
               mean(apply(2*GFCM.ICP95$MOE,1,max)))
GFCM.R85 = c(GFCM.minSE[1], GFCM.maxSE[1]); round(GFCM.R85, 3)
GFCM.R90 = c(GFCM.minSE[2], GFCM.maxSE[2]); round(GFCM.R90, 3)
GFCM.R95 = c(GFCM.minSE[3], GFCM.maxSE[3]); round(GFCM.R95, 3)


# FCM
FCM.ICP85 = CP(ytestDmat, FCM.predD, FCM.VarFp, 0.15)
FCM.ICP90 = CP(ytestDmat, FCM.predD, FCM.VarFp, 0.1)
FCM.ICP95 = CP(ytestDmat, FCM.predD, FCM.VarFp, 0.05)
FCM.ICPall = c(FCM.ICP85$ICP, FCM.ICP90$ICP, FCM.ICP95$ICP)
round(FCM.ICPall, 3) 


FCM.IL= c(mean(rowMeans(2*FCM.ICP85$MOE)), 
	  mean(rowMeans(2*FCM.ICP90$MOE)), 
          mean(rowMeans(2*FCM.ICP95$MOE)))
round(FCM.IL, 3)

# range of SE; refer to main paper
FCM.minSE = c(mean(apply(2*FCM.ICP85$MOE,1,min)), 
	      mean(apply(2*FCM.ICP90$MOE,1,min)), 
              mean(apply(2*FCM.ICP95$MOE,1,min)))
FCM.maxSE = c(mean(apply(2*FCM.ICP85$MOE,1,max)), 
	      mean(apply(2*FCM.ICP90$MOE,1,max)), 
              mean(apply(2*FCM.ICP95$MOE,1,max)))
FCM.R85 = c(FCM.minSE[1], FCM.maxSE[1]); round(FCM.R85, 3)
FCM.R90 = c(FCM.minSE[2], FCM.maxSE[2]); round(FCM.R90, 3)
FCM.R95 = c(FCM.minSE[3], FCM.maxSE[3]); round(FCM.R95, 3)